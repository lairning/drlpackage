# lairning Decisions
Contains lairning Deep Reinforcement Learning platform that Trains AI Agents to take optimal decisions on Simulated Environments (processes or systems) and make those AI Agents available through a Rest API to be used in the real world.



